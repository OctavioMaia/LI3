package exceptions;

public class DecisaoInvalidaException extends Exception {

	public DecisaoInvalidaException() {
		super();
	}

	public DecisaoInvalidaException(String msg) {
		super(msg);
	}
}
