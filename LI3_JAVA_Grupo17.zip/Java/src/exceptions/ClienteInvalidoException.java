package exceptions;

public class ClienteInvalidoException extends Exception {
	
	public ClienteInvalidoException() {
		super();
	}

	public ClienteInvalidoException(String msg) {
		super(msg);
	}
}
